// Graphics.h : Include file for standard system include files,
// or project specific include files.

#ifndef GRAPHICS_TEST_H
#define GRAPHICS_TEST_H

// TODO: Reference additional headers your program requires here.
int graphics_test();

#endif