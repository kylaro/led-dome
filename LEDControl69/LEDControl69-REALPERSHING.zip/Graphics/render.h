
#ifndef RENDER_H
#define RENDER_H
#include "../PatternsPlus/shared.h"

int domeToViewer(Dome * theDome, Shared * sharedObject);

#endif