#ifndef LEDENGINE_H
#define LEDENGINE_H
#include "../Objects/dome.h"
#include "shared.h"
void giveEngineDome(Dome * theDome);
void giveEngineShared(Shared* sharedObject);
void runEngine();


#endif