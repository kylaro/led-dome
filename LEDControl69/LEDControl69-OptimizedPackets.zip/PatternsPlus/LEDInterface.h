#ifndef LEDINTERFACE_H
#define LEDINTERFACE_H

class LEDInterface {
public:



};





#endif