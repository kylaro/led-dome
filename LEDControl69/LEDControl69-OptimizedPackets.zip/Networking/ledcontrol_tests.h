#ifndef LEDCONTROL_BASIC_TESTS_H
#define LEDCONTROL_BASIC_TESTS_H

int testChase();
#endif