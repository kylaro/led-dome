//
// Created by kylaro on 2/6/2021.
//

#ifndef LEDCONTROL_ADDRESSCONFIG_H
#define LEDCONTROL_ADDRESSCONFIG_H

//#define HOSTNAME_WIN "10.0.1.2"//apple
#define HOSTNAME_WIN "192.168.0.71"//wise tiger
#define PORT_WIN 5568
#define PACKET_LENGTH_WIN 638



#endif //LEDCONTROL_UDPSEND_WINDOWS_H
