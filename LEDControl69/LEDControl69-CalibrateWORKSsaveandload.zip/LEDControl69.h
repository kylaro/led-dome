﻿// LEDControl69.h : Include file for standard system include files,
// or project specific include files.
#ifndef ledcontrol69_h
#define ledcontrol69_h

#include <iostream>

// TODO: Reference additional headers your program requires here.
#endif