#include "EmptyEffect.h"

void EmptyEffect::apply() {
	

}